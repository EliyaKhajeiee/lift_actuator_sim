import { useState, useEffect, useRef } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Alert, AlertDescription } from './ui/alert';
import { Input } from './ui/input';
import { Label } from './ui/label';
import {
  Mic,
  MicOff,
  Power,
  ChevronUp,
  ChevronDown,
  StopCircle,
  Activity,
  AlertTriangle,
  CheckCircle2,
  Wifi,
  WifiOff,
} from 'lucide-react';
import { toast } from 'sonner';

type SystemStatus = 'idle' | 'listening' | 'processing' | 'active' | 'emergency';
type ArmPosition = number; // 0-100

interface Command {
  text: string;
  timestamp: Date;
}

// Speech Recognition types
declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

export function MainControl() {
  const [isListening, setIsListening] = useState(false);
  const [systemStatus, setSystemStatus] = useState<SystemStatus>('idle');
  const [armPosition, setArmPosition] = useState<ArmPosition>(0);
  const [targetPosition, setTargetPosition] = useState<ArmPosition>(0);
  const [lastCommand, setLastCommand] = useState<Command | null>(null);
  const [jamDetected, setJamDetected] = useState(false);
  const [piConnected, setPiConnected] = useState(false);
  const [piAddress, setPiAddress] = useState('192.168.1.100:5000'); // Default Pi address
  const [transcript, setTranscript] = useState('');
  
  const recognitionRef = useRef<any>(null);
  const wsRef = useRef<WebSocket | null>(null);

  // Initialize Speech Recognition
  useEffect(() => {
    if ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onstart = () => {
        console.log('Speech recognition started');
        setIsListening(true);
        setSystemStatus('listening');
      };

      recognitionRef.current.onresult = (event: any) => {
        const command = event.results[0][0].transcript.toLowerCase().trim();
        console.log('Recognized:', command);
        setTranscript(command);
        processCommand(command);
      };

      recognitionRef.current.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
        if (event.error === 'no-speech') {
          toast.error('No speech detected. Try again.');
        } else if (event.error === 'not-allowed') {
          toast.error('Microphone permission denied. Please enable microphone access.');
        } else {
          toast.error(`Speech recognition error: ${event.error}`);
        }
        setSystemStatus('idle');
      };

      recognitionRef.current.onend = () => {
        console.log('Speech recognition ended');
        setIsListening(false);
      };
    } else {
      toast.error('Speech recognition not supported in this browser. Use Chrome or Edge.');
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, []);

  // Connect to Raspberry Pi via WebSocket
  const connectToPi = () => {
    try {
      const ws = new WebSocket(`ws://${piAddress}/ws`);
      
      ws.onopen = () => {
        console.log('Connected to Raspberry Pi');
        setPiConnected(true);
        toast.success('Connected to Raspberry Pi');
        wsRef.current = ws;
      };

      ws.onmessage = (event) => {
        const data = JSON.parse(event.data);
        console.log('Received from Pi:', data);
        
        // Update arm position from Pi feedback
        if (data.position !== undefined) {
          setArmPosition(data.position);
        }
        
        // Handle jam detection
        if (data.jam) {
          setJamDetected(true);
          emergencyStop();
          toast.error('Jam detected by Raspberry Pi!');
        }

        // Handle status updates
        if (data.status) {
          toast.info(`Pi status: ${data.status}`);
        }
      };

      ws.onerror = (error) => {
        console.error('WebSocket error:', error);
        toast.error('Failed to connect to Raspberry Pi');
        setPiConnected(false);
      };

      ws.onclose = () => {
        console.log('Disconnected from Raspberry Pi');
        setPiConnected(false);
        toast.warning('Disconnected from Raspberry Pi');
        wsRef.current = null;
      };
    } catch (error) {
      console.error('Connection error:', error);
      toast.error('Failed to connect to Raspberry Pi');
    }
  };

  // Disconnect from Raspberry Pi
  const disconnectFromPi = () => {
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
      setPiConnected(false);
    }
  };

  // Send command to Raspberry Pi
  const sendCommandToPi = (command: string, value?: number) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      const message = JSON.stringify({ command, value });
      wsRef.current.send(message);
      console.log('Sent to Pi:', message);
    } else {
      console.warn('Not connected to Raspberry Pi - simulating locally');
      toast.warning('Not connected to Pi - running in simulation mode');
    }
  };

  // Simulate arm movement (when not connected to Pi)
  useEffect(() => {
    if (!piConnected && armPosition !== targetPosition && systemStatus === 'active') {
      const interval = setInterval(() => {
        setArmPosition((prev) => {
          if (prev < targetPosition) return Math.min(prev + 2, targetPosition);
          if (prev > targetPosition) return Math.max(prev - 2, targetPosition);
          return prev;
        });
      }, 50);

      return () => clearInterval(interval);
    }
  }, [armPosition, targetPosition, systemStatus, piConnected]);

  // Handle voice listening
  const toggleListening = () => {
    if (systemStatus === 'emergency') {
      toast.error('System in emergency stop mode. Reset required.');
      return;
    }

    if (!recognitionRef.current) {
      toast.error('Speech recognition not available');
      return;
    }

    if (!isListening) {
      try {
        recognitionRef.current.start();
        toast.info('Listening for voice command...');
      } catch (error) {
        console.error('Failed to start recognition:', error);
        toast.error('Failed to start voice recognition');
      }
    } else {
      recognitionRef.current.stop();
      setIsListening(false);
      setSystemStatus('idle');
    }
  };

  // Process commands
  const processCommand = (commandText: string) => {
    const command: Command = {
      text: commandText,
      timestamp: new Date(),
    };
    setLastCommand(command);
    setSystemStatus('processing');

    setTimeout(() => {
      const cmd = commandText.toLowerCase();
      
      if (cmd.includes('start') || cmd.includes('lift') || cmd.includes('up')) {
        setSystemStatus('active');
        setTargetPosition(100);
        sendCommandToPi('move', 100);
        toast.success('Lifting arm to maximum position');
      } else if (cmd.includes('stop') || cmd.includes('pause') || cmd.includes('halt')) {
        setSystemStatus('idle');
        setTargetPosition(armPosition);
        sendCommandToPi('stop');
        toast.info('Arm stopped at current position');
      } else if (cmd.includes('down') || cmd.includes('lower')) {
        setSystemStatus('active');
        setTargetPosition(0);
        sendCommandToPi('move', 0);
        toast.success('Lowering arm to minimum position');
      } else if (cmd.includes('half') || cmd.includes('middle') || cmd.includes('fifty')) {
        setSystemStatus('active');
        setTargetPosition(50);
        sendCommandToPi('move', 50);
        toast.success('Moving arm to middle position');
      } else {
        setSystemStatus('idle');
        toast.error(`Command "${commandText}" not recognized`);
      }
    }, 500);
  };

  // Emergency stop
  const emergencyStop = () => {
    setSystemStatus('emergency');
    setTargetPosition(armPosition);
    setIsListening(false);
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
    sendCommandToPi('emergency_stop');
    toast.error('EMERGENCY STOP ACTIVATED', {
      duration: 5000,
    });
  };

  // Reset system
  const resetSystem = () => {
    setSystemStatus('idle');
    setJamDetected(false);
    setTargetPosition(armPosition);
    sendCommandToPi('reset');
    toast.success('System reset');
  };

  // Get status color and icon
  const getStatusDisplay = () => {
    switch (systemStatus) {
      case 'idle':
        return {
          color: 'bg-gray-500',
          text: 'Idle',
          icon: <Power className="w-4 h-4" />,
        };
      case 'listening':
        return {
          color: 'bg-blue-500 animate-pulse',
          text: 'Listening',
          icon: <Mic className="w-4 h-4" />,
        };
      case 'processing':
        return {
          color: 'bg-yellow-500 animate-pulse',
          text: 'Processing',
          icon: <Activity className="w-4 h-4" />,
        };
      case 'active':
        return {
          color: 'bg-green-500',
          text: 'Active',
          icon: <CheckCircle2 className="w-4 h-4" />,
        };
      case 'emergency':
        return {
          color: 'bg-red-500',
          text: 'Emergency Stop',
          icon: <AlertTriangle className="w-4 h-4" />,
        };
    }
  };

  const statusDisplay = getStatusDisplay();

  return (
    <div className="space-y-6">
      {/* Raspberry Pi Connection Card */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-semibold">Raspberry Pi Connection</h2>
          <Badge className={`${piConnected ? 'bg-green-500' : 'bg-gray-500'} text-white px-4 py-2 text-base`}>
            <div className="flex items-center gap-2">
              {piConnected ? <Wifi className="w-4 h-4" /> : <WifiOff className="w-4 h-4" />}
              {piConnected ? 'Connected' : 'Disconnected'}
            </div>
          </Badge>
        </div>

        <div className="space-y-3">
          <div>
            <Label htmlFor="pi-address" className="text-base">
              Raspberry Pi Address (IP:Port)
            </Label>
            <Input
              id="pi-address"
              value={piAddress}
              onChange={(e) => setPiAddress(e.target.value)}
              placeholder="192.168.1.100:5000"
              className="mt-2 h-12 text-base"
              disabled={piConnected}
            />
          </div>
          
          {!piConnected ? (
            <Button
              onClick={connectToPi}
              className="w-full h-12 bg-blue-600 hover:bg-blue-700"
            >
              Connect to Raspberry Pi
            </Button>
          ) : (
            <Button
              onClick={disconnectFromPi}
              variant="outline"
              className="w-full h-12"
            >
              Disconnect
            </Button>
          )}
        </div>
      </Card>

      {/* Status Card */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-semibold">System Status</h2>
          <Badge className={`${statusDisplay.color} text-white px-4 py-2 text-base`}>
            <div className="flex items-center gap-2">
              {statusDisplay.icon}
              {statusDisplay.text}
            </div>
          </Badge>
        </div>

        {/* Arm Position Indicator */}
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-lg font-medium">Arm Position</span>
            <span className="text-2xl font-bold text-blue-600">{armPosition}%</span>
          </div>
          <Progress value={armPosition} className="h-3" />
          {systemStatus === 'active' && (
            <p className="text-sm text-gray-600">
              Moving to {targetPosition}%...
            </p>
          )}
        </div>

        {/* Last Command Display */}
        {lastCommand && (
          <div className="mt-4 p-3 bg-blue-50 rounded-lg">
            <p className="text-sm text-gray-600">Last Command</p>
            <p className="text-lg font-semibold text-gray-900 capitalize">
              {lastCommand.text}
            </p>
            <p className="text-xs text-gray-500 mt-1">
              {lastCommand.timestamp.toLocaleTimeString()}
            </p>
          </div>
        )}

        {/* Transcript Display */}
        {transcript && (
          <div className="mt-4 p-3 bg-green-50 rounded-lg">
            <p className="text-sm text-gray-600">Recognized Speech</p>
            <p className="text-base text-gray-900">"{transcript}"</p>
          </div>
        )}
      </Card>

      {/* Voice Control Card */}
      <Card className="p-6">
        <h2 className="text-2xl font-semibold mb-4">Voice Control</h2>
        
        {/* Main Voice Button */}
        <button
          onClick={toggleListening}
          disabled={systemStatus === 'emergency'}
          className={`w-full h-40 rounded-2xl transition-all duration-300 ${
            isListening
              ? 'bg-blue-600 scale-105 shadow-2xl'
              : 'bg-blue-500 hover:bg-blue-600 hover:scale-102'
          } disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center justify-center group`}
        >
          {isListening ? (
            <Mic className="w-20 h-20 text-white animate-pulse" />
          ) : (
            <MicOff className="w-20 h-20 text-white group-hover:scale-110 transition-transform" />
          )}
        </button>

        <p className="text-center text-lg mt-4 text-gray-600">
          {isListening
            ? 'Listening... Speak your command'
            : 'Tap to activate voice control'}
        </p>

        {/* Quick Command Buttons for Testing */}
        <div className="mt-6 space-y-3">
          <p className="text-sm font-medium text-gray-700">Quick Test Commands:</p>
          <div className="grid grid-cols-2 gap-3">
            <Button
              onClick={() => processCommand('start')}
              disabled={systemStatus === 'emergency'}
              variant="outline"
              size="lg"
              className="h-14"
            >
              <ChevronUp className="w-5 h-5 mr-2" />
              Start / Up
            </Button>
            <Button
              onClick={() => processCommand('stop')}
              disabled={systemStatus === 'emergency'}
              variant="outline"
              size="lg"
              className="h-14"
            >
              <StopCircle className="w-5 h-5 mr-2" />
              Stop
            </Button>
            <Button
              onClick={() => processCommand('down')}
              disabled={systemStatus === 'emergency'}
              variant="outline"
              size="lg"
              className="h-14"
            >
              <ChevronDown className="w-5 h-5 mr-2" />
              Down
            </Button>
            <Button
              onClick={() => processCommand('half')}
              disabled={systemStatus === 'emergency'}
              variant="outline"
              size="lg"
              className="h-14"
            >
              Middle
            </Button>
          </div>
        </div>
      </Card>

      {/* Emergency Stop Card */}
      <Card className="p-6 border-2 border-red-500">
        <h2 className="text-2xl font-semibold mb-4 text-red-600">Safety Controls</h2>
        
        <Button
          onClick={emergencyStop}
          disabled={systemStatus === 'emergency'}
          className="w-full h-20 bg-red-600 hover:bg-red-700 text-xl font-bold"
          size="lg"
        >
          <AlertTriangle className="w-8 h-8 mr-3" />
          EMERGENCY STOP
        </Button>

        {systemStatus === 'emergency' && (
          <Button
            onClick={resetSystem}
            className="w-full h-16 mt-4 bg-green-600 hover:bg-green-700 text-lg font-semibold"
            size="lg"
          >
            Reset System
          </Button>
        )}

        {jamDetected && (
          <Alert className="mt-4 border-yellow-500 bg-yellow-50">
            <AlertTriangle className="h-5 w-5 text-yellow-600" />
            <AlertDescription className="text-base">
              Jam detected in actuator. Please check the system before continuing.
            </AlertDescription>
          </Alert>
        )}
      </Card>

      {/* Available Commands Info */}
      <Card className="p-6 bg-gray-50">
        <h3 className="font-semibold text-lg mb-3">Available Voice Commands:</h3>
        <div className="grid grid-cols-2 gap-3 text-sm">
          <div className="p-3 bg-white rounded-lg">
            <span className="font-semibold text-blue-600">Start / Lift / Up</span>
            <p className="text-gray-600">Lift arm to maximum</p>
          </div>
          <div className="p-3 bg-white rounded-lg">
            <span className="font-semibold text-blue-600">Stop / Pause / Halt</span>
            <p className="text-gray-600">Stop at current position</p>
          </div>
          <div className="p-3 bg-white rounded-lg">
            <span className="font-semibold text-blue-600">Down / Lower</span>
            <p className="text-gray-600">Lower arm to minimum</p>
          </div>
          <div className="p-3 bg-white rounded-lg">
            <span className="font-semibold text-blue-600">Half / Middle / Fifty</span>
            <p className="text-gray-600">Move to middle position</p>
          </div>
        </div>
      </Card>
    </div>
  );
}