# Raspberry Pi Setup Guide for Ableware

## Overview
This guide will help you set up your Raspberry Pi to communicate with the Ableware web interface.

## Hardware Requirements
- Raspberry Pi (3B+ or 4 recommended)
- Linear actuator or robotic arm
- Motor driver (L298N or similar)
- Power supply for motors

## Software Setup

### 1. Install Required Packages on Raspberry Pi

```bash
sudo apt-get update
sudo apt-get install python3 python3-pip
pip3 install websockets asyncio RPi.GPIO
```

### 2. Python WebSocket Server Code

Save this as `ableware_server.py` on your Raspberry Pi:

```python
import asyncio
import websockets
import json
import RPi.GPIO as GPIO
from time import sleep

# GPIO Setup
MOTOR_PIN_1 = 17  # Adjust these to your actual GPIO pins
MOTOR_PIN_2 = 18
MOTOR_PWM_PIN = 27

GPIO.setmode(GPIO.BCM)
GPIO.setup(MOTOR_PIN_1, GPIO.OUT)
GPIO.setup(MOTOR_PIN_2, GPIO.OUT)
GPIO.setup(MOTOR_PWM_PIN, GPIO.OUT)

pwm = GPIO.PWM(MOTOR_PWM_PIN, 1000)  # 1000 Hz frequency
pwm.start(0)

# System state
current_position = 0
target_position = 0
is_moving = False
emergency_stopped = False

def move_actuator(target):
    """Move the linear actuator to target position (0-100)"""
    global current_position, is_moving
    
    if emergency_stopped:
        return
    
    is_moving = True
    
    if target > current_position:
        # Move up
        GPIO.output(MOTOR_PIN_1, GPIO.HIGH)
        GPIO.output(MOTOR_PIN_2, GPIO.LOW)
        pwm.ChangeDutyCycle(80)  # 80% speed
    elif target < current_position:
        # Move down
        GPIO.output(MOTOR_PIN_1, GPIO.LOW)
        GPIO.output(MOTOR_PIN_2, GPIO.HIGH)
        pwm.ChangeDutyCycle(80)
    else:
        # Already at position
        stop_motor()
        is_moving = False
        return
    
    # Simulate movement (replace with actual position feedback)
    steps = abs(target - current_position)
    for i in range(steps):
        if emergency_stopped:
            stop_motor()
            break
        
        if target > current_position:
            current_position += 1
        else:
            current_position -= 1
        
        sleep(0.1)  # Adjust based on your actuator speed
    
    stop_motor()
    is_moving = False

def stop_motor():
    """Stop the motor immediately"""
    GPIO.output(MOTOR_PIN_1, GPIO.LOW)
    GPIO.output(MOTOR_PIN_2, GPIO.LOW)
    pwm.ChangeDutyCycle(0)

def emergency_stop():
    """Emergency stop - halt all movement"""
    global emergency_stopped
    emergency_stopped = True
    stop_motor()
    print("EMERGENCY STOP ACTIVATED")

def reset_system():
    """Reset the emergency stop state"""
    global emergency_stopped
    emergency_stopped = False
    print("System reset")

async def handle_websocket(websocket, path):
    """Handle WebSocket connections from the web interface"""
    global target_position
    
    print(f"Client connected from {websocket.remote_address}")
    
    try:
        async for message in websocket:
            data = json.loads(message)
            command = data.get('command')
            value = data.get('value')
            
            print(f"Received command: {command}, value: {value}")
            
            if command == 'move':
                target_position = value
                # Send acknowledgment
                await websocket.send(json.dumps({
                    'status': f'Moving to {value}%'
                }))
                
                # Move actuator in background
                asyncio.create_task(move_and_report(websocket, value))
                
            elif command == 'stop':
                stop_motor()
                target_position = current_position
                await websocket.send(json.dumps({
                    'status': 'Stopped',
                    'position': current_position
                }))
                
            elif command == 'emergency_stop':
                emergency_stop()
                await websocket.send(json.dumps({
                    'status': 'Emergency stop activated'
                }))
                
            elif command == 'reset':
                reset_system()
                await websocket.send(json.dumps({
                    'status': 'System reset'
                }))
    
    except websockets.exceptions.ConnectionClosed:
        print("Client disconnected")
    except Exception as e:
        print(f"Error: {e}")

async def move_and_report(websocket, target):
    """Move actuator and report position updates"""
    global current_position
    
    move_actuator(target)
    
    # Send final position
    try:
        await websocket.send(json.dumps({
            'position': current_position,
            'status': 'Movement complete'
        }))
    except:
        pass

async def main():
    """Start the WebSocket server"""
    print("Starting Ableware WebSocket server on port 5000...")
    
    async with websockets.serve(handle_websocket, "0.0.0.0", 5000):
        print("Server running. Waiting for connections...")
        await asyncio.Future()  # Run forever

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nShutting down...")
    finally:
        stop_motor()
        GPIO.cleanup()
```

### 3. Run the Server

```bash
python3 ableware_server.py
```

### 4. Find Your Raspberry Pi's IP Address

```bash
hostname -I
```

Use this IP address in the web interface (e.g., `192.168.1.100:5000`)

## Testing the Voice Commands

### In the Web Interface:

1. **Allow Microphone Access**: When you first click the microphone button, your browser will ask for permission. Click "Allow"

2. **Test Voice Commands**:
   - Click the large blue microphone button
   - Wait for it to turn solid blue (listening)
   - Say one of these commands:
     - "Start" or "Up" - moves to 100%
     - "Stop" - stops at current position
     - "Down" - moves to 0%
     - "Half" or "Middle" - moves to 50%

3. **View Results**:
   - The "Recognized Speech" box will show what it heard
   - The "Last Command" box shows what command was processed
   - The progress bar shows the arm position

### Quick Test Buttons:

If voice isn't working yet, use the "Quick Test Commands" buttons to verify your Raspberry Pi connection is working.

## Troubleshooting

### Voice Recognition Not Working:
- **Use Chrome or Edge**: Safari and Firefox have limited support
- **Check Microphone Permission**: Look for a microphone icon in your browser's address bar
- **Speak Clearly**: Try speaking a bit louder and slower
- **Check Console**: Open browser DevTools (F12) and check the Console tab for errors

### Cannot Connect to Raspberry Pi:
- **Check IP Address**: Make sure you're using the correct IP from `hostname -I`
- **Check Port**: Default is 5000, make sure it's not blocked by firewall
- **Same Network**: Your computer and Pi must be on the same WiFi/network
- **Test Connection**: Try `ping 192.168.1.100` (use your Pi's IP)

### Firewall (if needed):
```bash
sudo ufw allow 5000
```

## WebSocket Message Format

### From Web → Pi:
```json
{
  "command": "move",
  "value": 100
}
```

Commands: `move`, `stop`, `emergency_stop`, `reset`

### From Pi → Web:
```json
{
  "position": 75,
  "status": "Moving",
  "jam": false
}
```

## Next Steps

1. **Calibrate**: Adjust the motor speed and timing in `move_actuator()`
2. **Add Sensors**: Integrate limit switches or encoders for precise positioning
3. **Jam Detection**: Add current sensing to detect jams
4. **Safety**: Add physical emergency stop button wired to GPIO

## GPIO Pin Reference

Default pins used (BCM numbering):
- GPIO 17: Motor Direction Pin 1
- GPIO 18: Motor Direction Pin 2  
- GPIO 27: Motor PWM (Speed Control)

Adjust these in the code based on your motor driver wiring.
